     // src/About.js
     import React from 'react';
     
     // import CarouselComponent from './CarouselComponent'; // If CarouselComponent.js is in the


     const about = () => {
     return (
     <div className='aboutbg'>     
          <h1>About Me</h1>
          <p>As a seasoned Front-End Web Designer with 4+ years of experience,
               I specialize in UI/UX, crafting beautiful and responsive web experiences.
               My passion lies in creating user-friendly interfaces that leave a lasting impression. 
               Proficient in HTML5, CSS3, Bootstrap, WordPress, React.js, JQuery, and more, I love to get new 
               experiences and always learn from my surroundings. I've done more than 285 projects.
               You can check it through portfolio section on this website. 
               I looking forward to any opportunities and challenges.
               </p>
 
               {/* <CarouselComponent /> */}
              
     </div>
     
     );
     };


     export default about;
