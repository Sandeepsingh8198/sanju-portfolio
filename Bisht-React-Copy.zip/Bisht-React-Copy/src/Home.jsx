import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';  // Import Bootstrap CSS
import background from "./bgimage.jpg"

const Home = () => {
     return (
         <div className=''>
               <div style={{ backgroundImage: `url(${background})` }} className='bg_image_banner'>
                    
                    <div className='container inner_content'>
                         <h5>I Am a</h5> 
                         <h1 className='mt-4'>Web Designer</h1>
                         <ul className='list_style mt-4'>
                         <li><span>web designer</span>Creative designer</li>
                         <li><span> UI & UX designer</span> User experience</li>
                         <li><span>web developmentr</span>Code creator</li>
                         </ul>
                    </div>
               </div>
         </div>
     );
   };
   export default Home;